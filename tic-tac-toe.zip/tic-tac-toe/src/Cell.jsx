const Cell = (props) => {
    let value = "_"
    const handleCellClick = () => {
        console.log("cell clicked", value);
        props.value = props.value === 'X' ? 'O' : 'X';
    }
  return <button onClick = {handleCellClick} className="cell">
    { props.value }
  </button>
}

export default Cell;