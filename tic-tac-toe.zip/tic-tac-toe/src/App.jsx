import Header from "./Header";
import Game from "./Game";
import './App.css'
const App = () => {
  return <>
    <Header title = "tic tac toe" />
    <Game />
  </>
}

export default App;