const Reset = () => {
  return <div className="reset">
    Reset
  </div>
}

export default Reset;