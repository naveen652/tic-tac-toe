import Status from "./Status";
import Board from "./Board";
import Reset from "./Reset";
const Game = () => {
  return <div className="game">
      <Status />
      <Board />
      <Reset />
  </div>
}

export default Game;