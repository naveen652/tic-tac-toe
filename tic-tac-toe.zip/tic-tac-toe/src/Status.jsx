const Status = () => {
  return <div className="status">
    Next Move: "O"
  </div>
}

export default Status;